
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.http.*;
public class MyServletRam extends HttpServlet 
{

public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
{
	PrintWriter out=res.getWriter();
	out.println("Welcome to httpservlet");
	String uname=req.getParameter("uname");
	String password=req.getParameter("password");
	out.println("Username:"+uname);
	out.println("Password:"+password);
	System.out.println("Welcome to http servlet");
}
}
