package exjsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Receiver  extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	PrintWriter out=response.getWriter();
	ServletContext context=getServletContext();
	
	out.println("technology:"+context.getAttribute("tech"));
	out.println("Course:"+request.getAttribute("course"));
}
}