package exjsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class check extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		ServletContext context=getServletContext();
		context.setAttribute("tech","J2EE");
		request.setAttribute("course","servlet");
		response.sendRedirect("http://www.google.com");
		/*
		String str=request.getParameter("user");
		System.out.println(str);
		System.out.println("rfsd");
	HttpSession session=request.getSession(false);
	session.setAttribute("com", "capgemini");
	//session.invalidate();
	String y=(String)session.getAttribute("com");
	System.out.println(y);*/
		PrintWriter out=response.getWriter();
		out.println("output:"+request.getRequestURI());
		
}
}