import java.io.*;

import javax.servlet.*;

public class MyServlet extends GenericServlet{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
{
	PrintWriter out=res.getWriter();
	out.println("Hello web servlet");
	System.out.println("hello servlet");
}
}
