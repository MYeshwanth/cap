import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Clientlogin extends HttpServlet {

	
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	Statement st=null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		HttpSession session=request.getSession(true);
		session.setAttribute("name",name);
		session.setAttribute("pass",password);
		if(name.equals("admin")&&password.equals("admin"))
		{
			try
			{
				 Class.forName("oracle.jdbc.driver.OracleDriver");
				 c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg610","training610");
				ps=c.prepareStatement("insert into login values(?,?)");
				ps.setString(1, name);
				ps.setString(2, password);
				ps.executeUpdate();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
	}
		else
		{
			out.println("enter correct details");

}}}
