package com.capgemini.tcc.bean;

import java.util.Date;

public class PatientBean {
int patient_id;
String patient_name;
int age;
long phone;
String description;
Date consulation_date;
public int getPatient_id() {
	return patient_id;
}
public void setPatient_id(int patient_id) {
	this.patient_id = patient_id;
}
public String getPatient_name() {
	return patient_name;
}
public void setPatient_name(String patient_name) {
	this.patient_name = patient_name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public long getPhone() {
	return phone;
}
public void setPhone(long k) {
	this.phone = k;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Date getConsulation_date() {
	return consulation_date;
}
public void setConsulation_date(Date consulation_date) {
	this.consulation_date = consulation_date;
}
}
