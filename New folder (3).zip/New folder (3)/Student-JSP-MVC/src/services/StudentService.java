package services;



import com.nag.StudentBean;

import dao.StudentDAO;

//import com.ram.beans.BookBean;
//import com.ram.dao.BookDAO;

public class StudentService 
{
 public int addStudentService( String student_name,String address,String city,int cs_marks,int physics_marks,int total)
 {
	/* //implement the business logic
	 String grade="";
	 if(price <= 300)
	 {
		 grade = "C";
	 }
	 else if(price <= 600)
	 {
		 grade = "B";
	 }
	 else
	 {
		 grade = "A";
	 }*/
	 
	 StudentDAO bookDAO = new  StudentDAO();
	 StudentBean studentBean = new StudentBean();
	 //wrap up all the four field values into bean
	 
	 
	 
	 
	 
	 studentBean.setStudent_name(student_name);
	 studentBean.setAddress(address);
	 studentBean.setCity(city);
	 studentBean.setCs_marks(cs_marks);
	 studentBean.setPhysics_marks(physics_marks);
	 studentBean.setTotal(total);
	 int updateResult = 0;
	 try
	 {
		 updateResult = StudentDAO.addStudent(studentBean);
		 return updateResult;
	 }
	 catch(Exception ex)
	 {
		 System.out.println(ex.toString());
		 return 0;
	 }
 }
 
 
 
 /* public ArrayList getBookDetailsById(int bookId)
  throws Exception
  {
	  BookDAO bookDAO = new BookDAO();
	 ArrayList result =  
		 bookDAO.getBookDetailsById(bookId);
	 
	 return result;
	 
  }*/
}
