package com.capgemini.lesson6.casting;

public class Derived extends Base {

	public Derived()
	{
		System.out.println("Consturctor in derived class");
	}
	
	public void methodY()
	{
		System.out.println("Y method in derived class");
	}
}
