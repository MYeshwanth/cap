package com.capgemini.lesson9;

class DefaultDemo {
	public static void main(String a[]) {
		String str = null;
		str.equals("Hello");
	}
}
