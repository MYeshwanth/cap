package com.capgemini.lesson9;
class TryCatchDemo {

	public static void main(String a[]) {
		String str = null;
		try {
			str.equals("Hello");
		} catch(ArithmeticException ne) {
			str = new String("hello");
			System.out.println(str.equals("Hello"));
		}
		catch(Exception e)
		{
			System.out.println("handling exception");
		}
		finally
		{
			System.out.println("i always execute");
		}
		System.out.println("Continuing in the program");
	}
}