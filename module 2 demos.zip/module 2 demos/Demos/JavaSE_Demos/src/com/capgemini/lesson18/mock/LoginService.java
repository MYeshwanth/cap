package com.igate.lesson20.mock;

public interface LoginService {
boolean login(String username, String password);
}
