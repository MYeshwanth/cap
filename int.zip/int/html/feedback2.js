
function populateCity()
{
st=document.getElementById("state").value; 
if(st=="TS")
{
document.getElementById("city").options[1].text="HYD";
document.getElementById("city").options[1].value="HYD";
document.getElementById("city").options[2].text="JGTL";
document.getElementById("city").options[2].value="JGTL";
}
else if(st=="TN") 
{
document.getElementById("city").options[1].text="CHN";
document.getElementById("city").options[1].value="CHN";
document.getElementById("city").options[2].text="PDH";
document.getElementById("city").options[2].value="PDH";
 }
 else if(st=="RJ")
 {
 document.getElementById("city").options[1].text="JPR";
 document.getElementById("city").options[1].value="JPR";
 document.getElementById("city").options[2].text="DNR";
 document.getElementById("city").options[2].value="DNR";
 }
 }
function displayfeedback()
{
var fname,ser, addr,pin,mob,dt,no,cit,st,ct;
fname=document.getElementById("fullname").value;

addr=document.getElementById("addrr").value;

pin=document.getElementById("Pincode").value;
mob=document.getElementById("Mobile no").value;
dt=document.getElementById("date").value;
em=document.getElementById("mail").value;
tot=document.getElementById("no").value; 
ser=document.getElementsByName("service");
cit=document.getElementsByName("citizen");
st=document.getElementById("state").value;
ct=document.getElementById("city").value;

selectedServices="";
selectedCitizen="";
for(var i=0;i<ser.length;i++)
{
if(ser[i].checked==true)
selectedServices+=ser[i].value+",";
}
for(var i=0;i<ser.length;i++)
{
if(ser[i].checked)
selectedCitizen=cit[i].value;
}

switch(a=document.getElementById("range").value)
{
case '10':
b="Poor";
break;
case '20':
b="Average";
break;
case '30':
b="Good";
break;
case '40':
b="better";
break;
case '50':
b="excellent";
break;
}
alert("Name: " +fname+"\n"+
"Address: "+addr+"\n"+
"Pincode: "+pin+"\n"+
"Mobile: "+mob+"\n"+
"Date "+dt+"\n"+
"Email "+em+"\n"+
"Total no of vehicles own: "+tot+"\n"+
"services:"+selectedServices+"\n"+
"Citizenship:"+selectedCitizen+"\n"+
"state:"+st+"\n"+"City:"+ct+"\n"
+"range"+a+"\n"+b
);

mywindow=window.open('','mywin','left=40, top=50, width=500, height=500');
mywindow.document.writeln(
"Name: " +fname+"<br>"+
"Address: "+addr+"<br>"+
"Pincode: "+pin+"<br>"+
"Mobile: "+mob+"<br>"+
"Date "+dt+"<br>"+
"Email "+em+"<br>"+
"Total no of vehicles own: "+tot+"<br>"+
"services:"+selectedServices+"<br>"+
"Citizenship:"+selectedCitizen+"<br>"+
"state:"+st+"<br>"+"City:"+ct+"<br>"
+"range"+a+"<br>"+b);
var a=window.prompt("enter value of x")
}
