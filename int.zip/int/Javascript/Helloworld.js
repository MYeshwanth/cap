<script type="javascript">
function sayHello()
{
return "HelloWorld";
}
</script>