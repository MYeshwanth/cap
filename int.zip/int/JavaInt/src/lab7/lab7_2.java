package lab7;
import java.util.*;
public class lab7_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ArrayList<String> al=new ArrayList<String>();
   al.add("Yeshwanth");
   al.add("Suresh");
   al.add("Haneef");
  // Arrays.sort(al);
   //ArrayList.sort((Comparator) al);
   TreeSet<String> ts=new TreeSet<String>();
   ts.addAll(al);
	   System.out.println(ts);
	}

}
