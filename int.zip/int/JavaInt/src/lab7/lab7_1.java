package lab7;

import java.util.Arrays;

public class lab7_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] str= {"Apple","samsung","Lenovo","moto","LG","Micromax"};
		Arrays.sort(str);
		for(int i=0;i<str.length;i++)
		System.out.println(str[i]);
		
	}

}
