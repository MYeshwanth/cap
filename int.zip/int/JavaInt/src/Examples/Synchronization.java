package Examples;
class Callme
{
	 void call(String msg)
	{
		System.out.println("["+msg);
		try
		{
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			System.out.println("Interrupted Exception");
		}
		System.out.println("]");
	}
}
class Caller implements Runnable
{
	String msg;
	Callme target;
	Thread t;
	public Caller(Thread t,Callme targ,String s)
	{
		t=new Thread(this);//this denotes implementing the runnable interface
		target=targ;
		msg=s;
		t.start();
	}
	@Override
 public void run() {
		//synchronized(target) {
		target.call(msg);
	//}
}
}
 class Synchronization {
public static void main(String args[])
{
	Callme target1=new Callme();
	Thread t=null;
	Caller ob2=new Caller(t,target1,"Synchronization");
	Caller ob1=new Caller(t,target1,"Hello");
	Caller ob3=new Caller(t,target1,"World");
}
}
