package Examples;
class Newthread extends Thread{
	public void run()
	{
		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println("child thread:"+i);
				Thread.sleep(600);
			}
		}
		catch(Exception e)
		{
			System.out.println("child interrupted");
		}
		System.out.println("existing child thread");
	}
}
public class Extendthread
{
	public static void main(String args[])
	{
		Newthread nt=new Newthread();
		nt.start();
		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println("Main thread:"+i);
				Thread.sleep(300);
			}
		}
		catch(Exception e)
		{
			System.out.println("Main interrupted");
		}
	}
}