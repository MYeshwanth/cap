package Examples;
import java.util.*;
import java.util.stream.Collectors;
public class StreamAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer>list=new ArrayList<Integer>();
list.add(10);
list.add(5);
list.add(20);
list.add(11);

List<Integer>list1=list.stream().filter(i->i%2==0).collect(Collectors.toList());
System.out.println(list1);
	
List<Integer>list2=list.stream().map(i->i*2).collect(Collectors.toList());
System.out.println(list2);
	
	}

}
