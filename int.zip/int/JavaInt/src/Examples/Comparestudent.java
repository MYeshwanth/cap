package Examples;
import java.util.*;
public class Comparestudent {
	public static void main(String args[])
	{
		Student2 st1=new Student2("yeshwanth",1);
		Student2 st2=new Student2("vinay",3);
		Student2 st3=new Student2("srujan",4);
		Student2 st4=new Student2("vishal",2);
		
		List<Student2>ls=new ArrayList<Student2>();
		ls.add(st1);
		ls.add(st2);
		ls.add(st3);
		ls.add(st4);
	Collections.sort(ls);//internally implements the compareTo method of comparable Interface
	Iterator i=ls.iterator();
	while(i.hasNext())
	{
		Object element=i.next();
		Student2 st=(Student2)element;
		System.out.println("Name: "+st.name+" Age :"+st.age+"\n");
	}
	}
}
 class Student2 implements Comparable
{
	 String name;
	int age;
		public Student2(String name, int age) {
			this.name = name;
			this.age= age;
		}
		public int compareTo(Object o)
		{
			if((this.age)==((Student2)o).age) //stores sorted age in HEAP memory
				return 0;
			else if((this.age)>((Student2)o).age) 
				return 1;
			else
				return -1;
	}
}