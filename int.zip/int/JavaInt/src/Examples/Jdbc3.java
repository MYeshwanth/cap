package Examples;
import java.util.*;
import java.sql.*;
import java.util.Scanner;

public class Jdbc3 {
	Connection c;
	  Statement st;
	 PreparedStatement ps;
	public void connect() throws SQLException
	{
		 try
		  {
			  Class.forName("oracle.jdbc.OracleDriver");
			 c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg610","training610");
			  System.out.println("connected");
 }
		  catch(ClassNotFoundException e)
		  {
			  System.out.println(e);
		  }
	}
	
	
	 void insert() throws SQLException
	{
	try
	{
		Scanner sc=new Scanner(System.in);
		int eno=sc.nextInt();
		String ename=sc.next();
		long sal=sc.nextLong();
		System.out.println(eno+" "+ename+" "+sal);
		 ps=c.prepareStatement("insert into emp3 values(?,?,?)");
		ps.setInt(1,eno);
		ps.setString(2,ename);
		ps.setLong(3,sal);
		System.out.println("done");
		ps.executeUpdate();
		
	}
	catch(SQLException se)
	{
		System.out.println(se);
	}
    }  
	public void close() throws SQLException
	{
		ps.close();
		c.close();
	}
	public static void main(String[] args) throws SQLException {
		Jdbc3 j=new Jdbc3();
		j.connect();
		j.insert();
		j.close();
}
}