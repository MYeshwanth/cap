package Examples;
import java.util.function.*;
public class Predicateinterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Predicate<String> pr=a->(a.length()>5);//create predicate
System.out.println(pr.test("yeshwanth"));//calling predicate method


/*Predicate<String> pr=a->(a>5);//create predicate
System.out.println(pr.test(20));*/

	}

}
