package Examples;
import java.io.*;
public class Serializaion1 {
	FileOutputStream fos=null;
	  ObjectOutputStream oos=null;
	 
	public void init()throws Exception
	{
			  fos=new FileOutputStream("Student.dat");
			   oos=new  ObjectOutputStream(fos);
	}
	public void write()
	{
		 Student e=new Student();
		 e.name="Yeshwanth";
		  e.address="6-4-237,Korutla";
		  e.rollno="123456";
		  e.roomno=111;
		try
		{
			 oos.writeObject(e);
			 System.out.println("object is serialized and stored in 'student.dat'");
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
	}
	public void close() throws IOException
	{
		oos.close();
	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Serializaion1 s1=new Serializaion1(); 
		s1.init();
		s1.write();
		s1.close();
	}
}
