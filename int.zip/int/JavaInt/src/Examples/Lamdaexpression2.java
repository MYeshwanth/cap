package Examples;
interface Transaction2// functional interface can have only 1 abstract method
{
	void withdraw(int amt);
}
public class Lamdaexpression2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Transaction2 ob=(int amt)->
    {
    System.out.println("Amount "+amt);
    };
    ob.withdraw(900);
	}
}
