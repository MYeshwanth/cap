package Examples;
import java.util.function.*;
public class Constructorreference {

	public static void main(String[] args) {
		
Supplier<Item>s1=Item::new;
System.out.println(s1.get());
	}
}