package Examples;
 class Hellorun implements  Runnable{
public void run()
{
	System.out.println("Welcome to capgemini");
}
 }
public class Hellorunnable
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Hellorun hr=new Hellorun();//runnable object
Thread t=new Thread(hr);
t.start();
	}
}
