package Examples;
enum Student1
{
 John(11), Bella(10), Sam(13), Viraaj(9);
 private int age;                   //variable defined in enum Student
 int getage() { 
	 return age;
	 }  //method defined in enum Student
 Student1(int age)  //constructor defined in enum Student
 {
  this.age= age;
 }
}

class Test
{
 public static void main( String args[] )
 {
  Student S;
  System.out.println("Age of Viraaj is " +Student1.Viraaj.getage()+ "years");
 }
}