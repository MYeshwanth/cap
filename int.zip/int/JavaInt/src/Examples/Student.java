package Examples;
import java.io.*;
public class Student implements Serializable {
	public String name;
	public String address;
	public transient String rollno;
	public int roomno;
}
