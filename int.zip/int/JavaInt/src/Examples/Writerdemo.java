package Examples;

import java.io.*;
import java.util.*;
public class Writerdemo {
	BufferedWriter bw=null;//purpose is global declaration because 
	FileWriter fw=null;
	 void init() throws IOException
	{
		 fw=new FileWriter("t2.txt");
		 bw=new BufferedWriter(fw); 
	}
	void write() 
	{
		Scanner sc=new Scanner(System.in);
		String s=" ";
		 try
		 {
			 while(!s.equals("q"))
			 {
				 s=sc.nextLine();
			 
			 if(!s.equals("q"))
			 {
				 bw.write(s);
				 bw.newLine();
			 }
	 	 }}
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
			
			}
	public void close() throws IOException
	{
		bw.close();
	}
public static void main(String args[]) throws Exception
{
	Writerdemo ob=new Writerdemo();
	ob.init();
	ob.write();
	ob.close();
}
}
