package Examples;
import java.io.*;
public class Serialization {
	public static void main(String[] args) {
  Student e=new Student();
  e.name="Yeshwanth";
  e.address="6-4-237,Korutla";
  e.rollno="123456";
  e.roomno=111;
  try
  {
	  FileOutputStream fos=new FileOutputStream("Student.dat");
	  ObjectOutputStream oos=new  ObjectOutputStream(fos);
	  oos.writeObject(e);
	  oos.close();
	  System.out.println("object is serialized and stored in 'student.dat'");
  }
  catch(Exception ie)
  {
	  ie.printStackTrace();
 }
}
}