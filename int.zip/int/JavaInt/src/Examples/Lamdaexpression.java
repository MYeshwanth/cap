package Examples;

interface Transaction
{
	void withdraw(int amt);
}
class WithDraw implements Transaction
{
	public void withdraw(int amt)
	{
		System.out.println("Amount "+amt);
	}
}
public class Lamdaexpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 WithDraw wd=new WithDraw();
 wd.withdraw(900);
	}

}
