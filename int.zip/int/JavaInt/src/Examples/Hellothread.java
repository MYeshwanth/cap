package Examples;

public class Hellothread {
	public static void main(String[] args) {
		Ht h=new Ht();
		h.start();
	}
}
class Ht extends Thread
{
public void run()
{
	System.out.println("hello welcome to threads");
}
}