package Examples;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;

public class Fileinput {

	public static void main(String[] args) {
		 byte b[]=new byte[40];
		   try
		   {
			   /*FileInputStream fi=new FileInputStream("t1.txt");
			   fi.read(b);
			   String str=new String(b);
			  System.out.println(str);*/
			  FileReader fr = new FileReader("t1.txt");
			  BufferedReader br = new BufferedReader(fr);
			 String data;
			 while((data=br.readLine())!=null)
				 System.out.println(data);
			   fr.close();
	       }
		   catch(Exception e)
		   {
			   e.printStackTrace();//method of throwable class in which it throws an error where it is occured
		   }
		   
	}
}
