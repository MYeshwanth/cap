package Examples;
import java.io.*;
public class Deserialization extends Student  {
	/*public String toString()
	{
		return "Name:"+name+ "\n address"+address+"\n roll no:"+rollno+"\n room no"+roomno;
	}*/
	public static void main(String args[]) throws Exception
	{  Student e=null;
		try
		  {
			  FileInputStream fis=new FileInputStream("Student.dat");
			  ObjectInputStream ois=new  ObjectInputStream(fis);
			  e=(Student) ois.readObject();
			 // System.out.println(e);
			  ois.close();
		  }
		
	catch(ClassNotFoundException c)
	{
		System.out.println("student class not found");
		c.printStackTrace();
	}
		 System.out.println("Name:"+e.name);
		 System.out.println("Address:"+e.address);
		 System.out.println("Roll no:"+e.rollno);
		 System.out.println("Room no:"+e.roomno);
	}
}
