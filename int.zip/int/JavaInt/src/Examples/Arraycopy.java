package Examples;
import java.util.Arrays;
public class Arraycopy {
	public static void main(String args[])
	{
		int n[]= {2,3,7,56};
		int t[]=Arrays.copyOfRange(n,1,3);
		System.out.println(t[0]);
		System.out.println();
		
		for(int i=0;i<n.length;i++)
			System.out.println(n[i]);
		System.out.println();
	
		System.out.println("In T-array");
		for(int i=0;i<t.length;i++)
			System.out.println(t[i]);
	}
}
