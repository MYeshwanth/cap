package Examples;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import java.util.*;
import javax.swing.text.*;
public class Hashmap {
	public static void main(String[] args) {
		HashMap<String,Integer>hashmap=new HashMap<String,Integer>();
		//HashSet<String> hs=new HashSet<String>();
		hashmap.put("one", new Integer(1));
		hashmap.put("two", new Integer(2));
		hashmap.put("three", new Integer(3));
		hashmap.put("three", new Integer(5));
		hashmap.put(null, new Integer(4));
		/*hs.addAll(hashmap.keySet());
		System.out.println(hs);
		System.out.println("HashMap contains:"+hashmap.size()); 
		
		System.out.println("hashmap values"+hashmap.values());
	 System.out.println("retrieving all keys from hashmap");

	 Iterator<String>iterator=hs.iterator();
	 while(iterator.hasNext())
	 {
		 System.out.println(iterator.next());
	 }
	 System.out.println("retrieving all key value pairs from hashmap");
	 Iterator<Map.Entry<String,Integer>> itr=hashmap.entrySet().iterator();
	 while(itr.hasNext())
	 {
		 System.out.println(itr.next());
	 }*/
	 System.out.println("Hash Map keys from array list");
	 ArrayList<String>al=new ArrayList<String>();
	 al.addAll(hashmap.keySet());
	 /* Iterator<String>i=al.iterator();
	 while(i.hasNext())
	 {
		 System.out.println(i.next());
	 }*/
	 System.out.println(al);
	 System.out.println("Hash map values from tree set");
	 TreeSet<Integer> ts=new TreeSet<Integer>();
	// Iterator<String>i1=al.iterator();
		 ts.addAll(hashmap.values());
		 System.out.println(ts);
	}
}
