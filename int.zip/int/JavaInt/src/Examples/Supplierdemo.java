package Examples;
import java.util.function.*;
public class Supplierdemo {
	public static void main(String[] args) {
Supplier<String>s=()->
{
	String s1[]= {"yesh","vinay","srujan"};
	int x=(int)(Math.random()*3);
	return s1[x];
};
System.out.println(s.get());
	}
}