/**
 * 
 */
package Examples;

/**
 * @author YMACHA
 *
 */
public class ArrayDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int a[]=new int[12];
   a[0]=12;
   a[1]=22;
   a[2]=24;
   a[3]=16;
   for(int i=0;i<a.length;i++)
	   System.out.println(a[i]);
   System.out.println();
   for(int i:a)
	   System.out.println(i);
	}
}
