package Examples;
interface Transaction1
{
	void withdraw(int amt);
}
public class Lamdaexpression1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Transaction1 ob=new Transaction1()
				{
			public void withdraw(int amt)
			{
				System.out.println("Amount "+amt);
			}
				};
				ob.withdraw(900);
				}
		
		
	}
