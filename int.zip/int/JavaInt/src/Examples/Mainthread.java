package Examples;
import java.util.*;
public class Mainthread extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String>seasonlist=new ArrayList<String>();
seasonlist=Arrays.asList(new String[]
{
	"winter","summer","spring","autumn"
	});
	for(String value:seasonlist)
	{
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			System.err.println(e.getMessage());
		}
		System.out.println(value);
}
	}

}
