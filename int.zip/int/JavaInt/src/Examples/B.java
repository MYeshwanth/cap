package Examples;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class B {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
B b=new B();
Set s=new TreeSet();
s.add("2");s.add("3");s.add("1");s.add("6");s.add("10");s.add("50");
Iterator i=s.iterator();
while(i.hasNext()) {
	System.out.println(i.next()+" ");
}
	}

}
