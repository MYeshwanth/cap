package Examples;
import java.util.function.*;
public class Functioninterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Function<String,Integer>f=a->a.length();
System.out.println(f.apply("yeshwanth"));
	}

}
