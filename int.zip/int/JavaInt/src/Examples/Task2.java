package Examples;

import java.util.*;

class Employee1
{
	int id;
	String name;
	Double salary;
	
	Employee1(int id,String name,Double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	public String toString()
	{
		return id+" "+name+" "+salary;
	}
}
public class Task2 {

	public static void main(String[] args)throws Exception {
		
  Employee1 e1=new Employee1(101,"yeshwanth",30000d);
  Employee1 e2=new Employee1(102,"suresh",30001d);
  Employee1 e3=new Employee1(103,"Haneef",29999d);
  
  List<Employee1>emplist=new ArrayList<Employee1>();
  
  emplist.add(e1);
  emplist.add(e2);
  emplist.add(e3);
  
 /* Optional<Double>totalsalary=emplist.stream()
  .map(emp->emp.getSalary())
  .reduce((a,b)->a+b);
  
  System.out.println("Total Salary"+totalsalary.get());*/
  
  Iterator<Employee1>itr=emplist.stream().iterator();
		  //.reduce((Employee1 a,Employee1 b)->a.getSalary()<b.getSalary()?b:a);
  while(itr.hasNext())
  {
  	System.out.println(itr.next());
  }
  /*if(maxsalary.isPresent())
	  System.out.println("Employee with max salary:"+maxsalary.get());
 */
  /*emplist.forEach(e->System.out.println(e.getName()+" "+e.getSalary()+" "+(e.getSalary()+e.getSalary()*15/100)));
  System.out.println();
  //In java 8, the list interface supports the sort method directly, no need to use Collections.sort anymore.
  emplist.sort((Employee1 s1,Employee1 s2)->s1.getId()-s2.getId());
  emplist.forEach((s)->System.out.println(s));
  System.out.println();*/
  
	}

}
