package Examples;
import java.util.*;
import java.util.stream.*;
public class Reducedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Stream.of(10,20,5).reduce((x,y)->x+y).ifPresent(System.out::println);
List<Integer>intlist=Arrays.asList(5,15,87,245);
Optional<Integer>result=intlist.stream().reduce((a,b)->a>b?a:b);
if(result.isPresent())
{
	System.out.println("result:"+result.get());
}
	}

}
