package Examples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Jdbc2 {
	public static void main(String[] args) throws Exception {
		  try
		  {
Class.forName("oracle.jdbc.OracleDriver");
Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg610","training610");
System.out.println("connected");
Scanner sc=new Scanner(System.in);
int eno=sc.nextInt();
String ename=sc.next();
long sal=sc.nextLong();
PreparedStatement ps=c.prepareStatement("insert into emp3 values(?,?,?)");
ps.setInt(1,eno);
ps.setString(2,ename);
ps.setLong(3,sal);
System.out.println("done");
ps.executeUpdate();
ps.close();
c.close();
}
		  catch(SQLException se)
	      {
		  System.out.println(se);
	      }  
	}
}
