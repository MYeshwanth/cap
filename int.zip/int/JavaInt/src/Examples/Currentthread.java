package Examples;
class A implements Runnable
{
	public void run()
	{
		int i=1;
		try
		{
			for(int n=5;n>0;n--) {
				System.out.println(n);
				Thread.sleep(5000);
			}
		}
		catch(Exception e)
		{
			System.out.println("Main thread interrupted");
		}
	}
}
public class Currentthread {
	public static void main(String args[])
	{
		
		A a=new A();
		Thread t=new Thread();
		System.out.println("current thread"+t);
		t.setName("My thread");
		System.out.println("current thread"+t);
		t.start();
	}
	
}