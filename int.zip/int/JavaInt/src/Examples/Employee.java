package Examples;
import java.util.*;
public class Employee {

	private int Id;
	private String name;
	private long salary;
	
	
	public Employee(int id, String name, long salary) {
		Id = id;
		this.name = name;
		this.salary = salary;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Employee e1=new Employee(1,"yesh",25000);
   Employee e2=new Employee(2,"suresh",25000);
   Employee e3=new Employee(3,"haneef",25000);
   HashSet<Employee> h1=new HashSet<Employee>();
   h1.add(e1);
   h1.add(e2);
   h1.add(e3);
   Iterator i1=h1.iterator();
//System.out.println(h1);
  while(i1.hasNext())
  {
	  System.out.println(i1.next()+" ");
  }
	}
	public String toString()
	{
		return "Id:"+Id+"\nName"+name+"\n salary="+salary;
		
	}
}
