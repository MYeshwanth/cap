package Examples;
class suresh
{
	suresh()
	{
	System.out.println("A");
	}
}
 class yesh extends suresh
{
	 yesh()
	{
		System.out.println("B");
	}
}
public class C extends yesh{
	C()
	{
		System.out.println("C");
	}
	public static void main(String args[])
	{
		C c=new C();
		
	}
	}