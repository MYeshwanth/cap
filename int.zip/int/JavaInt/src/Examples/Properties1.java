package Examples;
import java.util.*;
import java.io.*;
import java.lang.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
public class Properties1 {

	public static void main(String[] args) {
		
		Properties prop=new Properties();
		try
		{
			prop.load(new FileInputStream("Data.properties"));
			String user=prop.getProperty("username");
			String pass=prop.getProperty("password");
			String eno=prop.getProperty("e");
			String name=prop.getProperty("en");
			String url=prop.getProperty("url");
			Class.forName("oracle.jdbc.OracleDriver");
			Connection c=DriverManager.getConnection(url,user,pass);
			System.out.println("Connected");
			Statement stmt=c.createStatement();
			String sql="select "+eno +", "+name+", "+"sal from emp3";
			System.out.println(sql);
	     	ResultSet rs=stmt.executeQuery(sql);
	     	while(rs.next())
	     	  {
	     		  System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
	     	  }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
