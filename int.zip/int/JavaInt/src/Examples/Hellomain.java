package Examples;
public class Hellomain {
	public static void main(String args[])
	{
Hellothread ht=new Hellothread();
ht.start();
}
}
