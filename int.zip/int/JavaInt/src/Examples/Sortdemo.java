package Examples;
import java.util.*;
public class Sortdemo {
	public int[] sortno(int ar[])
	{
		int temp;
		Arrays.sort(ar);
		return ar;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {7,6,2,0};
		int k;
		Sortdemo sd=new Sortdemo();
		int sortedarray[]=sd.sortno(a);
		for(k=0;k<sortedarray.length;k++)
  System.out.println(sortedarray[k]+" ");
	}

}
