package Examples;
import java.util.function.*;
import java.util.*;
public class ConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Consumer<String>c=s->System.out.println(s);
c.accept("java");
/*IntConsumer i=()->Integer.MAX_VALUE;
System.out.println(i.getAsInt());
*/
	}

}
