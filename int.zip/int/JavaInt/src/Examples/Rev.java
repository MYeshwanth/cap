package Examples;
import java.util.*;
public class Rev {
public static void be() {
	Set s=new TreeSet();
	s.add("2");
	s.add("1");
	s.add("3");
	Iterator it=s.iterator();
	while(it.hasNext())
		System.out.println(it.next()+" ");
}
	public static void main(String[] args) {
	Rev r=new Rev();
	r.be();
	}
}
