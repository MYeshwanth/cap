package Examples;
import java.sql.*;
import java.util.*;
public class Jdbcodbc1 {
	public static void main(String[] args) throws Exception {
		  try
		  {
  Class.forName("oracle.jdbc.OracleDriver");
  Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg610","training610");
  System.out.println("connected");
 Scanner sc=new Scanner(System.in);
 int eno=sc.nextInt();
 String ename=sc.next();
 long sal=sc.nextInt();
  Statement  st=c.createStatement();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
 //int i=st.executeUpdate("Insert into emp3 values(?,?,?)");
  String sql="insert into emp3 values("+eno+",'"+ename+"',"+sal+")";
 //PreparedStatement ps=new PreparedStatement
System.out.println(eno+ename+sal);
int i=st.executeUpdate(sql);

 System.out.println("done");
		  }
		  catch(SQLException se)
		      {
			  System.out.println(se);
		      }
			}
}
