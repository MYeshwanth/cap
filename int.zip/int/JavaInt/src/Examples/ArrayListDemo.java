package Examples;
import java.util.*;
public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add("mango");
		al.add("apple");
		al.add(0,"orange");
  System.out.println(al);
for(int j=0;j<al.size();j++)
{
	System.out.println(al.get(j)+" ");
}
System.out.println();
Iterator i1=al.iterator();
System.out.println("array list --->");
while(i1.hasNext())
{
	System.out.println(i1.next()+ " ");
}
System.out.println();
for(Object i:al)
	System.out.println();
}
		
}
