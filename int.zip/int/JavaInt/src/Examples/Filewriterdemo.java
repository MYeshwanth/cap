package Examples;
import java.io.*;
public class Filewriterdemo {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
   try
   {
	   FileWriter fw=new FileWriter("out.txt");
	   BufferedWriter bw=new BufferedWriter(fw);
	   bw.write("too much code");
	   bw.close();
   }
   catch(Exception e)
   {
	   System.err.println(e);
   }
	}

}
