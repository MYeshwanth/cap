package Examples;
import java.util.*;
import java.io.FileOutputStream;
public class Fileoutput {
	public static void main(String[] args) {
   //byte b[]=new byte[45];
   String ch=" ";
   try
   {
	   Scanner sc=new Scanner(System.in);
	   //System.in.read(b);
	   FileOutputStream fo=new FileOutputStream("t1.txt",true);
	   ch=sc.next();
	   fo.write(ch.getBytes());
	  fo.write("\r\n".getBytes());
	   fo.close();
   }
   catch(Exception e)
   {
	  e.printStackTrace();//method of throwable class in which it throws an error where it is occured
   }
	}
}