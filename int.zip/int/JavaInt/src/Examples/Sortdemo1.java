package Examples;

public class Sortdemo1 {
public static int[] sortnos(int sarr[])
{
	int i,j,temp;
	for(i=0;i<sarr.length-1;i++)
	{
		for(j=i+1;j<sarr.length;j++)
		{
			if(sarr[i]>sarr[j])
			{
				temp=sarr[i];
				sarr[i]=sarr[j];
				sarr[j]=temp;
			}
		}
	}
	return sarr;
}
	public static void main(String args[])
	{
		int a[]= {7,6,2,0};
		Sortdemo1 sd=new Sortdemo1();
		int sortedarray[]=sortnos(a);
		for(int k=0;k<sortedarray.length;k++)
	  System.out.print(sortedarray[k]+" ");
	}
}