package lab6;
import java.util.*;
class FullException extends Exception
{
	public String toString()
	{
		return "Names cannot be blank";
	}
}
public class Person {
	
 private String fname;
 private String lname;
 private char gender;
public Person() {
	fname="FNAME";
	lname="LNAME";
	gender='N';
}
Person(String fn,String ln,char gn)
{
	fname=fn;
	lname=ln;
	gender=gn;
}
public void setDetails(String fname,String lname,char gender)
{
	this.fname=fname;
	this.lname=lname;
	this.gender=gender;
}

public String getFname() {
	return fname;
}
public String getLname() {
	return lname;
}
public char getGender() {
	return gender;
}
public static void main(String args[])throws Exception
{
	Person p=new Person();
	System.out.println("enter details");
	Scanner sc=new Scanner(System.in);
	String s,s1;
	try
	{
		System.out.println("enter first name");
		s=sc.next();
		if(s.length()==0)
		{
			throw new FullException();
		}
		else
		{
			System.out.println("enter lastname");
			s1=sc.next();
			if(s1.length()==0)
			{
				throw new FullException();
			}
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
