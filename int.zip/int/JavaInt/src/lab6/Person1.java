package lab6;
import lab4.*;
import java.util.*;
class Ageexception extends Exception
{
	public String toString()
	{
		return "age cannot be less than 15";
	}
}
public class Person1 extends Accountdetails{

private String name;
private int age;

	public void setName(String name) {
	this.name = name;
}

public void setAge(int age) {
	this.age = age;
}

	public String getName() {
	return name;
}

public float getAge() {
	return age;
}
public String toString()
{
	return "Name"+name+"\nBalance"+getbal();
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int acc=100;
Person1 p=new Person1();
Scanner sc=new Scanner(System.in);
int age;
try
{
	System.out.println("enter age");
	age=sc.nextInt();
	if(age<=15)
	{
		throw new Ageexception();
	}
}
catch(Exception e)
{
	System.out.println(e);
}
	}
}
