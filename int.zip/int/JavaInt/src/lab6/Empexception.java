package lab6;
import java.util.*;
class EmployeeException extends Exception
{
	public String toString()
	{
		return "low employee salary";
	}
}
public class Empexception {
  
  private float salary;
  
public void setSalary(float salary) {
	this.salary = salary;
}
public float getSalary() {
	return salary;
}
public static void main(String args[])
{
  //System.out.println("Enter employee details");
	Scanner sc=new Scanner(System.in);
	float salary;
	try
	{
		System.out.println("enter salary of employee");
		salary=sc.nextFloat();
		if(salary<3000)
		{
			throw new EmployeeException();
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}