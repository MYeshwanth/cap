package userinput;

import java.util.Scanner;

import bean.Employee;

public class User_input extends Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User_input ul=new User_input();
		Scanner s=new Scanner(System.in);
		System.out.print("enter name");
		ul.name=s.nextLine();
		System.out.println("enter id");
		ul.id=s.nextInt();
		System.out.println("enter salary");
		ul.salary=s.nextInt();
		System.out.println("enter designation");
		ul.designation=s.next();
		ul.insuranceSchema=ul.scheme(ul.salary,ul.designation);
		s.close();
		ul.details();
			}
			void details()
			{
				System.out.println("name :"+this.name+"\nid :"+this.id+"\nsalary :"+this.salary+"\ndesignation :"+this.designation+"\ninsuranceScheme :");
				if(this.insuranceSchema=='O')
					System.out.println("No scheme");
				else if(this.insuranceSchema=='p')
				System.out.println("enter the correct details");
				else 
					System.out.println("Scheme "+this.insuranceSchema);
			}
	}
