package lab2;
import java.util.*;
public class Student {

	String name[]=new String[4];
	int id[]=new int[4];
	int j=0,k=0;
	public void accept()   
	{
		System.out.println("Enter student details");
		
			Scanner sc=new Scanner(System.in);
			id[j]=sc.nextInt();
			name[j]=sc.next();
		 j++;
	}
	public void display()
	{
		System.out.println("Displaying student details");
		
			System.out.println("Id is "+id[k]);
			System.out.println("Name  is "+name[k]);
			System.out.println();
		k++;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Student stud[]=new Student[10];
		
		for(int i=0;i<3;i++)
		{
			stud[i]=new Student();
			stud[i].accept();
			
		}
		for(int i=0;i<3;i++)
		{
			stud[i].display();
		}
	}
}
