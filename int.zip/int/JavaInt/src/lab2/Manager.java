/**
 * 
 */
package lab2;

/**
 * @author YMACHA
 *
 */
public class Manager extends Employee {

	/**
	 * @param args
	 */
	
		// TODO Auto-generated method stub
private String deptName;
public Manager()
{}
public Manager(int eid,String ename,String deptName)
{
	super(eid,ename);
	this.deptName=deptName;
}

public String toString()
{
	return super.toString()+"\n manager department is:"+deptName;
}
public void managePeople()
{
	System.out.println("I am capable of managing people");
}
}

