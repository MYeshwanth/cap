package lab2;
import java.util.Scanner;
public class PosOrNeg {

/**
 * @author YMACHA
 *
 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		      Scanner sc=new Scanner(System.in);
		      System.out.println("enter the number:");
      int a= sc.nextInt();
      if(a<0) {
    	  System.out.println("Negative number");
      }
    	  else {
    	  System.out.println("Positive number");
}
}  
}
