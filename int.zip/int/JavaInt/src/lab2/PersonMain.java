/**
 * 
 */
package lab2;

/**
 * @author YMACHA
 *
 */ 
public class PersonMain extends PersonClass{

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    PersonClass pc=new PersonClass("macha","yeshwanth",'M');
    System.out.println(pc);
	}
}
