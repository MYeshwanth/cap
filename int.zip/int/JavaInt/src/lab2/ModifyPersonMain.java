/**
 * 
 */
package lab2;

/**
 * @author YMACHA
 *
 */ 
public class ModifyPersonMain extends ModifyPersonclass{

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ModifyPersonclass pc=new ModifyPersonclass("macha","yeshwanth",'M',123456);
    System.out.println(pc);
	}
}
