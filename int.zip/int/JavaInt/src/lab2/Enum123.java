/**
 * 
 */
package lab2;

/**
 * @author YMACHA
 *
 */
public class Enum123 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee e=new Employee(101,"Yeshwanth");
System.out.println(e);

System.out.println("-------------------------------------");

Manager e1=new Manager(102,"suresh","Mech");
System.out.println(e1); 
	e1.managePeople();	
	Manager m=(Manager)e;
	m.managePeople();
	}

}
