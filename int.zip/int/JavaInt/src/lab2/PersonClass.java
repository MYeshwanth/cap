package lab2;
public class PersonClass {
	private String fname;
	private String lname;
	private char gender;
	private int phonenumber;
	
	PersonClass()
	{
	}
	PersonClass(String fname,String lname,char gender)
	{
		this.fname=fname;
		this.lname=lname;
		this.gender=gender;
		
	}
	
	
	public void setFname(String fname) {
		this.fname = fname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	public char getGender() {
		return gender;		
	}
	
	
	public String toString()
	{
		return "First name:"+fname+"\nLast name: "+lname+"\nGender: "+gender;
	}

}
