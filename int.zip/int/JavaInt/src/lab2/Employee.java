/**
 * 
 */
package lab2;

/**
 * @author YMACHA
 *
 */
public class Employee {

	/**
	 * @param args
	 */
	private int eid;
	private  String ename;
	private static String Company="capgemini";
	
	public Employee() {
	
	}

	public Employee(int eid, String ename) {
		this.eid = eid;
		this.ename = ename;
	}
	
	public int getEid() {
		return eid;
	}
	
	public String getEname() {
		return ename;
	}
	
	public static String getCname() {
		return Company;
	}
	
	public void setEid(int eid) {
		this.eid=eid;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
	}
    public String toString()
    {
    	return "Employee id:"+eid+"\n Employee name:"+ename+"\n company name:"+Company;
    }
    public void managePeople()
    {
    	System.out.println("I am from employee class");
    }
    
 }
