package lab3;
import java.util.*;
import java.time.*;
public class Systemdate {

	public void dmy(int y,Month m,int d)
	{
		LocalDate ld=LocalDate.of(y, m, d);
		LocalDate tod=LocalDate.now();
		int e,f,g;
		Period age=Period.between(ld,tod);
		e=age.getDays();
		f=age.getMonths();
		g=age.getYears();
		System.out.println("DAYS "+e);
		System.out.println("months "+f);
		System.out.println("years "+g);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("days, months and years with regards to current system date. ");
   Systemdate  po=new Systemdate ();
		Scanner sc=new Scanner(System.in);
				System.out.println("Enter the date");
		System.out.println("Enter the day");
		int n,p;
		Month a;
		n=sc.nextInt();
		System.out.println("Enter the year");
		p=sc.nextInt();
		a=Month.OCTOBER;
		po.dmy(n,a,p);

	}

}
