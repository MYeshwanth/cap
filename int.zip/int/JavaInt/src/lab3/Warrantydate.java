package lab3;
import java.util.*;
public class Warrantydate{

	
	public static void wardate(int a,int b)
	{
		System.out.println("expiry date is"+a+"/"+(b+1));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("accept product purchase date and warrantee period (in terms of months and years)");
		System.out.println("enter purchase month and year of product");
		Scanner sc=new Scanner(System.in);
		int c,d;
		c=sc.nextInt();
		d=sc.nextInt();
		System.out.println("warrany expires on");
		Warrantydate.wardate(c,d);
	}

}




