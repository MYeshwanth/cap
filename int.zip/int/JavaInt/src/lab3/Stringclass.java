package lab3;
import java.util.*;
public class Stringclass {

	private String s;
	public void input(String s,int a)
	{
		switch(a)
		{
		case 1:
			System.out.println(s+s);
			break;
		case 2:
			StringBuilder sb=new StringBuilder(s);
			for(int i=0;i<sb.length();i++)
			{
				if(i%2==0)
					sb.setCharAt(i,'#');
			}
			System.out.println(sb);
			break;
		case 3:
			StringBuilder sb1=new StringBuilder(s);
			char[] arr=sb1.toString().toCharArray();
			for(char ch:arr)
			{
				if(sb1.indexOf(String.valueOf(ch))==1)
					continue;
				else
					sb1.append(ch);
			}
			System.out.println(sb1.toString());
			break;
		case 4:
			for(int i=0;i<s.length();i++)
			{
				char ch=s.charAt(i);
				if(i%2==0)
					System.out.println(Character.toUpperCase(ch));
				else
					System.out.println(Character.toLowerCase(ch));
			}
	  }
	}
	public static void main(String[] args) {
		Stringclass so=new Stringclass();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your string");
		String s;
		s=sc.next();
		System.out.println("Enter your choice \n 1.Add String to Itself\n2.Replace odd position with #\n3.Remove Duplicate characters in string\n4.change odd characters to Upper case\n");
       int b;
       b=sc.nextInt();
       so.input(s,b);
	}

}
