package lab3;
import java.time.*;
import java.util.*;
public class Twodays {
	public void dmy(int y,Month m,int d,int y1,Month m1,int d1)
	{
		LocalDate ld=LocalDate.of(y, m, d);
		LocalDate ld1=LocalDate.of(y1, m1, d1);
		int e,f,g;
		Period age=Period.between(ld, ld1);
		e=age.getDays();
		f=age.getMonths();
		g=age.getYears();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("two LocalDates and print the duration between dates in days, months and years. ");
		Twodays po=new Twodays();
		Scanner sc=new Scanner(System.in);
				System.out.println("Enter the date");
		System.out.println("Enter the day");
		int n,p;
		Month a;
		n=sc.nextInt();
		System.out.println("Enter the year");
		p=sc.nextInt();
		a=Month.OCTOBER;
		System.out.println("Enter the date 2");
		System.out.println("Enter the day");
		int n1,p1;
		Month b;
		n1=sc.nextInt();
		System.out.println("Enter the year");
		p1=sc.nextInt();
		b=Month.OCTOBER;
		po.dmy(n,a,p,n1,b,p1);
		
	}
}