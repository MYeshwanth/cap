package lab3;
import java.util.*;
import java.time.*;
import java.text.*;
public class Zone {

	
	public static void dzone(String str)
	{
		DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date d=df.parse(str);
		System.out.println(d);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("accept zone id and print the current date and time with respect to given zone");
      Date d=new Date();
      System.out.println("enter the timezone id");
      Scanner sc=new Scanner(System.in);
      String str=sc.next();
      Program6.dateZone(str);
		
	}

}
