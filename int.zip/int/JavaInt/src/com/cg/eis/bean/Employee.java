package com.cg.eis.bean;

import java.io.Serializable;
import service.Services;
public abstract class Employee extends Services implements Serializable {

	public int id;
	public String name;
	public int salary;
	public String designation;
	public char insuranceSchema;
	
/*	public Employee() {
		id=0;
		name="NULL";
		salary=0;
		designation="NULL";
		insuranceSchema="NULL";
	}
*/
/*	public Employee(int empId, String empName,long salary,String design,String inschema) {
		this.Id = empId;
		this.name = empName;
		this.salary = salary;
		this.design= design;
		this.inschema= inschema;
	}
*/
/*	public void setEmpId(int empId) {
		this.Id = empId;
	}

	public void setEmpName(String empName) {
		this.name = empName;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public void setDesign(String design) {
		this.design = design;
	}

	public void setInschema(String inschema) {
		this.inschema = inschema;
	}

	public int getEmpId() {
		return Id;
	}

	public String getEmpName() {
		return name;
	}

	public long getSalary() {
		return salary;
	}

	public String getDesign() {
		return design;
	}

	public String getInschema() {
		return inschema;
	}
	*/
}

