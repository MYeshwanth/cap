package com.sample.bean;
import org.apache.log4j.Logger;
public class Message {
	//create a logger for Message class
public static final Logger logger=Logger.getLogger(Message.class);
	private String msg;
	public void setMessage(String msg) {
	            this.msg = msg;
  //log the messages for each priority level
	      }
	public String getMessage() {
  //log messages for each priority level
	return msg;
	      }

}
