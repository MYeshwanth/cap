package service;

public class Services {
	public char scheme(int salary,String designation)
	{
		if(salary>5000 && salary<20000 && designation.equalsIgnoreCase("System_Associate"))
		{
			return 'C';
		}
		else if(salary>=20000 && salary<40000 && designation.equalsIgnoreCase("Programmer"))
		{
			return 'B';
		}
		else if(salary>=40000 && designation.equalsIgnoreCase("Manager"))
		{
			return 'A';
		}
		else if(salary<5000 && designation.equalsIgnoreCase("Clerk"))
		{
			return 'O';
		}
		else
		{
			return 'p';
		}
		
	}
		}
		interface EmployeeService{
			char scheme(int salary,String designation);
		}
