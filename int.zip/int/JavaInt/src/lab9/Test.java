package lab9;
import static org.junit.Assert.assertEquals;
public class Test {

	@org.junit.Test
	public void getDay() {
		System.out.println("Day");
		Date d=new Date(9,02,2019);
		assertEquals(9,d.getDay());
	}
	
	@org.junit.Test
	public void getMonth() {
		System.out.println("Month");
		Date d1=new Date(9,02,2019);
		assertEquals(02,d1.getMonth());
	}
	
	@org.junit.Test
	public void getYear() {
		System.out.println("Year");
		Date d=new Date(9,02,2019);
		assertEquals(2019,d.getYear());
	}
	
}
