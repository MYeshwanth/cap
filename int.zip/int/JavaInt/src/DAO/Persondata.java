package DAO;
import java.io.*;
import java.util.Properties;
public class Persondata {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties prop=new Properties();
		try
		{
			prop.load(new FileInputStream("Data1.properties"));
			String firstname=prop.getProperty("firstname");
			String lastname=prop.getProperty("lastname");
			String empid=prop.getProperty("empid");
			String sal=prop.getProperty("sal");
			System.out.println("First name:"+firstname+" lastname:"+lastname+"\n salary: "+sal+"\n employee id"+empid);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}