package DAO;
import java.sql.*;
public class EmployeeDAO {
	Connection cn;
	PreparedStatement ps;
	Statement stmt;
	ResultSet rs;
	public void insert(Empbean sb) throws Exception
	{
		cn=CommonConnection.getCon();
		ps=cn.prepareStatement("insert into emp values(?,?,?)");
		ps.setInt(1,sb.getId());
		ps.setString(2, sb.getName());
		ps.setInt(3, sb.getSal());
		ps.executeUpdate();
		System.out.println("Inserted");
	}
	public void update(Empbean sb2) throws Exception
	{
		cn=CommonConnection.getCon();
		ps=cn.prepareStatement("update emp set ename=? where eid=?");
		ps.setInt(2,sb2.getId());
		ps.setString(1, sb2.getName());
		ps.executeUpdate();
		System.out.println("updated");
	}
	public void search(Empbean sb3) throws Exception
	{
		cn=CommonConnection.getCon();
	  stmt=cn.createStatement();
		
		int i=stmt.executeUpdate("select * from emp where eid="+sb3.getId());
		
		if(i>0)
		{
			ResultSet rs=stmt.executeQuery("select * from emp where eid="+sb3.getId());
		while(rs.next())
		{
			System.out.println("Eid: "+rs.getInt(1)+" Ename:"+rs.getString(2)+" Salary:"+rs.getInt(3));
		}
		}
		else
		{
			System.out.println("No rows found");
		}
		}
	public void sort() throws SQLException
	{
		cn=CommonConnection.getCon();
		 stmt=cn.createStatement();
		int i=stmt.executeUpdate("select * from emp order by sal");
		System.out.println(i);
		ResultSet rs=stmt.executeQuery("select * from emp order by sal");
		//ResultSet rs1=stmt.executeQuery("select * from emp order by eid");
		System.out.println("sorted by salary");
				while(rs.next())
				{
		System.out.println("Eid: "+rs.getInt(1)+" Ename:"+rs.getString(2)+" Salary:"+rs.getInt(3));
	}
				System.out.println();
				
	}
	public void sortid() throws SQLException
	{
		cn=CommonConnection.getCon();
		 stmt=cn.createStatement();
		ResultSet rs=stmt.executeQuery("select * from emp order by eid");
		
		System.out.println("sorted by id");
				while(rs.next())
				{
		System.out.println("Eid: "+rs.getInt(1)+" Ename:"+rs.getString(2)+" Salary:"+rs.getInt(3));
	}
				System.out.println();
				
	}
	public void close() throws SQLException
	{
		cn.close();
		ps.close();
		stmt.close();
		rs.close();
		System.out.println("call closed");
	}
	
}
