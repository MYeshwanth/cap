package DAO;
import java.util.*;
public class DAOExample1 {
	public static void main(String[] args) throws Exception {
		EmployeeDAO emp1=new EmployeeDAO();
		System.out.println("1.Insert\t2.Update\t3.Search\t4.Sorting by salary\t5.sorted by ID\t6.Exit");
		Scanner sc=new Scanner(System.in);
			int ch=sc.nextInt();
		 switch(ch)
		 {
		 case 1: 
		        Empbean sb1=new  Empbean();
		        int id=sc.nextInt();
		        String name=sc.next();
		        int sal=sc.nextInt();
		        sb1.setId(id);
		        sb1.setName(name);
		        sb1.setSal(sal);
		        emp1.insert(sb1);
		        break;
		        
		 case 2:
			 Empbean sb2=new  Empbean();
		 int id1=sc.nextInt();
		 String name1=sc.next();
		 
		 sb2.setId(id1);
		 sb2.setName(name1);
		
		 emp1.update(sb2);
		       break;
		       
		 case 3:
			 Empbean sb3=new  Empbean();
			 int id2=sc.nextInt();
			 sb3.setId(id2);
			 emp1.search(sb3);
			 break;
			 
		 case 4:
			 emp1.sort();
			 break;
		 case 5:
			 emp1.sortid();
			 break;
		 case 6:
			 emp1.close();
		      break;
		      
		   default:
		        	 System.out.println("Invalid choice");
		 }
	  }
	}