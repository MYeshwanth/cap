package DAO;
interface LamdaSpace
{
	public void st(String st);
}
public class Lamda1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LamdaSpace l1=st->
{
	char ch[]=st.toCharArray();
	for(char d:ch)
	{
		System.out.print(d+" ");
	}
};
l1.st("hello");
	}
}
