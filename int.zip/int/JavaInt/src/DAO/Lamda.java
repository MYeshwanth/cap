package DAO;
import java.util.function.*;
interface Multiplication
{
	public int multiply(int a,int b);
}
public class Lamda {

	public static void main(String[] args) {
	Multiplication m=(a,b)->
	{
    int b1=1;
    for(int i=0;i<a*b;i++)
    {
    	b1=b1*a;
    }
    return b1;
	};
	int result=m.multiply(3, 2);
	System.out.println(result);
	
}
}
