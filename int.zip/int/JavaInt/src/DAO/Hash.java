package DAO;

import java.util.HashSet;
import java.util.Iterator;
import java.io.*;
public class Hash {

	public static void main(String[] args) throws IOException {
	HashSet<String> hs=new HashSet<String>();
	hs.add("yesh");
	hs.add("suresh");
	hs.add("Haneef");
	Iterator<String>itr=hs.iterator();
FileWriter fw=new FileWriter("hash1.txt",false);
BufferedWriter bw=new BufferedWriter(fw);

while(itr.hasNext())
{
	String s=itr.next();
	bw.write(s+"\n");
	bw.newLine();
}
bw.close();
	}

}
