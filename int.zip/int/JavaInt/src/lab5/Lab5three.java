package lab5;
public abstract class Lab5three {
	long accnum;
	double balance;
	Person accholder;
	void deposit(double amount) {
		this.balance+=amount;
	}
	abstract boolean withdraw(double amount);
	double getBalance(){
		return this.balance;
	}
	public String toString(){
		return String.format("name:"+this.accholder.getname()+"balance:"+this.getBalance());
	}
	public static void main(String args[])
	{
		Lab5three acc1=new SavingsAccount("smith",25,2000);
		Lab5three acc2=new CurrentAccount("kathy",30,3000);
		acc1.withdraw(2000);
		acc2.withdraw(21000);
		System.out.println(acc1);
		System.out.println(acc2);
	}
	Lab5three(String name,float age,double balance)
	{
		this.accholder=new Person();
		this.accholder.setname(name);
		this.accholder.setage(age);
		this.balance=balance;
		this.accnum=(long)(Math.random()*1000000);
	}
}
class Person{
	private String name;
	private float age;
	public String getname()
	{
		return this.name;
	}
	public void setname(String name)
	{
		this.name=name;
	}
	public float getage()
	{
		return this.age;
	}
	public void setage(float age)
	{
		this.age=age;
	}
}
class CurrentAccount extends Lab5three{
	final float overdraftLimit=-500;
	CurrentAccount(String name,float age,double balance)
	{
		super(name,age,balance);
	}
	boolean withdraw(double amount)
	{
		if(this.balance-amount>overdraftLimit)
		{
			this.balance-=amount;
			return true;
		}
		else
			System.out.println(this.accholder.getname()+"overdraft limit exceeded");
	return false;
	}
}
 
	class SavingsAccount extends Lab5three{
	final float minimumbal=500;
	SavingsAccount(String name,float age,double balance)
	{
	super(name,age,balance);
	}
	boolean withdraw(double amount)
	{
	if(this.balance-amount>500)
	this.balance-=amount;
	else System.out.println(this.accholder.getname()+"minimum balance of 500 must be there");
	System.out.println("your current balance is"+this.getBalance());
	return false;
	}
	}