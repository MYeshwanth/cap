package lab5;
public class Employee {
	
	
	private int empId;
	private String empName;
	//private static String compName="Capgemini";
	private long salary;
	private String design;
	private String inschema;
	
	public Employee() {
		empId=0;
		empName="NULL";
		salary=0;
		design="NULL";
		inschema="NULL";
	}

	public Employee(int empId, String empName,long salary,String design,String inschema) {
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.design= design;
		this.inschema= inschema;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public void setDesign(String design) {
		this.design = design;
	}

	public void setInschema(String inschema) {
		this.inschema = inschema;
	}

	public int getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

	public long getSalary() {
		return salary;
	}

	public String getDesign() {
		return design;
	}

	public String getInschema() {
		return inschema;
	}
	
}
	
    
	