package bean;
import java.io.Serializable;

import service.Services;

public abstract class Employee extends Services implements Serializable{

	
		// TODO Auto-generated method stub
public int id,salary;
public String name,designation;
public char insuranceSchema;
	

}