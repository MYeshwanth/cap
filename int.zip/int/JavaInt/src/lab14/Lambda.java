package lab14;

import java.util.function.Consumer;

public class Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<String> c=(String str) -> System.out.println(String.valueOf(str).replaceAll(".","$0 "));
		c.accept("chaitanya");

	}

}