package lab8;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths; 
import java.util.Collections;
import java.util.List; 
import java.util.Scanner;
/* * Java Program read a text file in multiple way. * This program demonstrate how you can use FileReader, * BufferedReader, and Scanner to read text file, * along with newer utility methods added in JDK 7 * and 8. */ 
public class ScannerFile
{
	public static void main(String[] args) throws Exception
	{
		File f=new File("numbers.txt");
		   Scanner sc=new Scanner(f);
		   Scanner s=sc.useDelimiter(",");
		   int i;
		   while(s.hasNext())
		   {
			   i=s.nextInt();
			   if(i%2==0)
			   {
				   System.out.println(i);
			   }
		   }
		   s.close();
	}
	}