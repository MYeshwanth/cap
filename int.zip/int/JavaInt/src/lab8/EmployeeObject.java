package lab8;
import java.io.*;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
public class EmployeeObject extends Employee{

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		EmployeeObject sl=new EmployeeObject();
		   Scanner s=new Scanner(System.in);
		   System.out.println("enter the name");
		   sl.name=s.nextLine();
		   System.out.println("enter the id");
		   sl.id=s.nextInt();
		   System.out.println("enter the salary");
		   sl.salary=s.nextInt();
		   System.out.println("designation");
		   sl.designation=s.next();
		   sl.insuranceSchema=sl.scheme(sl.salary,sl.designation);
		   System.out.println(sl.insuranceSchema);
		   s.close();
		   FileOutputStream fo=new FileOutputStream("emp.txt");
		   ObjectOutputStream out= new ObjectOutputStream(fo);
		   out.writeObject(sl);
		   out.flush();
		   out.close();
		   System.out.println("Success");
		   ObjectInputStream in=new ObjectInputStream(new FileInputStream("emp.txt"));
		   Employee s3=(EmployeeObject) in.readObject();
		   System.out.println(s3.id+""+s3.name);
		   in.close();		

	}
}
