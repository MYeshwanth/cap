package lab8;
import java.io.*;
import java.util.*;
public class ReverseFile {
	
	 public static void main(String[] args) 
     {
		 try {
				FileReader f=new FileReader("C:\\Users\\YMACHA\\core java solutions\\rev.txt");
				int i=0;
				StringBuffer sb=new StringBuffer();
				while((i=f.read())!=-1)
				{
					sb.append((char)i);
				}
				String h=sb.reverse().toString();
				System.out.println(h);
				f.close();
				FileWriter f1= new FileWriter("C:\\Users\\YMACHA\\core java solutions\\rev.txt");
				f1.write(h);
				f1.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
     }
}