package lab4;

public class Holder extends Accountdetails{

	
	private String name;
	private float age;
	
	public void setName(String name) {
		this.name = name;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public float getAge() {
		return age;
	}
  public String toString()
  {
	  return "Person name:"+name+"\nAvailable Balance="+getbal();
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int a=100;
  Holder yesh=new Holder();
  Holder suresh=new Holder();
   yesh.setName("yeshwanth");
   yesh.setBal(2000);
   yesh.setAno(a++);
   
   suresh.setName("suresh");
   suresh.setBal(3000);
   suresh.setAno(a++);
   
   yesh.depo(2000);
   suresh.with(2000);
   
   yesh.getbal();
   suresh.getbal();
   
   System.out.println(yesh);
   System.out.println(suresh);
	}

}
