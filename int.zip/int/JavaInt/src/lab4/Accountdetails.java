package lab4;

public class Accountdetails {

	private long ano;
	private double bal;
	
	public double getbal()
	{
		return bal;
	}
	public long getano()
	{	return ano;
	}
	
	public void setAno(long ano) {
		this.ano = ano;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public void depo(double money)
	{
		bal=bal+money;
		System.out.println("available balance is"+bal);
	}
	public void with(double money)
	{
		bal=bal-money;
		System.out.println("available balance is"+bal);
	}
	public String toString()
	{
		return "Account balance="+bal;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
