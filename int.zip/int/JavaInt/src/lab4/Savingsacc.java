package lab4;

public class Savingsacc extends Accountdetails {

	private final int minbalance=500;
	public void with(double money)
	{
		double bal;
		Accountdetails ad=new Accountdetails();
		double d=ad.getbal();
		if(d<minbalance)
		{
			System.out.println("cannot withdraw");
		}
		else
		{
			System.out.println("you can withdraw");
			bal=ad.getbal()-money;
			System.out.println("Blance is "+bal);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
