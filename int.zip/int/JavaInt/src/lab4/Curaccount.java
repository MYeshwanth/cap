package lab4;

public class Curaccount extends Accountdetails {

	
	private int ol;
	Accountdetails ad=new Accountdetails();
	
	public void with(double money)
	{
		double bal=ad.getbal();
		boolean c;
		c=(bal<ol)?true:false;
		System.out.println(c);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
