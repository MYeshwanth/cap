package lab2;
import java.util.*;
public class Largest {
int a[];
int great()
{
	int  l=0,temp;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the no of numbers");
	int n=sc.nextInt();
	a=new int[n];
	for(int i=0;i<n;i++)
	{
		 a[i]=sc.nextInt();
	}
	/*for(int i=0;i<n;i++)
	{ 
	//another logic
		if(l<a[i])
			l=a[i];
	}*/
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i]>=a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	return a[0];
}
public static void main(String args[])
{
	Largest la=new Largest();
	System.out.println("Largest Number is "+la.great());
}
}
