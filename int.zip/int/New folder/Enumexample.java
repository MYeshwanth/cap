/**
 * 
 */
package lab2;
import java.util.*;
/**
 * @author YMACHA
 *
 */

public class Enumexample {

	public enum Enum12
	{
		ADDITION,SUBTRACTION,MULTIPLICATION,DIVISION;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Enum12 e= Enum12.ADDITION;
  Scanner sc=new Scanner(System.in);
  System.out.println("enter operation");
  String s=sc.next();
  String s2;
  int flag=0;
  
	   for(Enum12 d:Enum12.values())
	   {
		   s2=d.toString();
		   if(s.equalsIgnoreCase(s2))
		   flag=1;
	}
	   if(flag==1)
		   System.out.println("present");
	   else 
		   System.out.println("Not present");
	   
}
}
