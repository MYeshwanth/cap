package lab2;
import java.util.*;
 class WithException extends Exception
{
	public String toString()
	{
		return "Cannot be withdrawn";
	}
}
public class Account {
	public static void main(String[] args)throws Exception
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter amount to be withdrawn");
		int w=sc.nextInt();
			try
			{
				if(w>=1000)
				{
				throw new WithException();	
				}
				else
				{
					System.out.println("You can withdraw your amount");
				}
				
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}

