/**
 * 
 */
package lab2;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.*;

/**
 * @author YMACHA
 *
 */

class PasswordException extends Exception
{
	public String toString()//overrides the exception
	{
		return "wrong password";
	}
}
public class TaskException {

	//private static String Pass;

	/**
	 * @param args
	 */
	static final String Pass="yesh";

	public static void main(String[] args) {
		int count=1;
		// TODO Auto-generated method stub
   while(count>0)
   {
		System.out.println("enter password");
		BufferedReader br=new BufferedReader( new InputStreamReader(System.in));
	
		
		try
		{
			String s=br.readLine();
		 if(s.equals(Pass))
		 {
			 System.out.println("Welcome");
		 }
		 else
		 {
			if(count>=3)
			{
				System.out.println("system shutdown");
				throw new PasswordException();
				
			}
			else
			{
				System.out.println("Enter password again");
				count++;
			}
		 }
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.exit(0);
		}	
   }
   
   
	}
}

		
   