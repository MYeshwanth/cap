/**
 * 
 */
package lab2;

/**
 * @author YMACHA
 *
 */

class MynegativeAgeException extends Exception
{
	public String toString()
	{
		return "age cannot be negative";
	}
}
 public class Custom {

	/**
	 * @param args
	 */
	static int getage()
	{
		return -10;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int age=getage();
    try
    {
    	if(age<0)
    	{
    		throw new MynegativeAgeException();
    	}
    	else
    	{
    		System.out.println("correct age");
    	}
    }
    catch(Exception e)
    {
    	System.out.println(e);
    }
    System.out.println("hai");
	}
}
