package lab2;

public class VarargExample {

	
	
	public int sum1(int ... args)
	{
		System.out.println("Argument length: "+args.length);
		int sum=0;
		for(int x:args)
		{
			sum=sum+x;
		}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VarargExample obj=new VarargExample();
		System.out.println(obj.sum1(1,2,3,4,5));
	}

}
