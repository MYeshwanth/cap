package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Userbean;

import com.controller.Commonconnection;


public class Createprofile extends HttpServlet{
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	Statement st=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PrintWriter out=response.getWriter();
			 c=Commonconnection.getCon();
			 Userbean bean=new Userbean();
		response.setContentType("text/html");
	
		String id1=request.getParameter("username");
		String password1=request.getParameter("password");
		String role=request.getParameter("role1");
	String ag=request.getParameter("agent");
	
	

	
	//System.out.println(role);
		bean.setUserName(id1);
		
		bean.setPassWord(password1);
	bean.setRoleCode(role);
	bean.setAgent(ag);
	
	if(bean.getRoleCode().equals("Claim Adjuster")) 
	 {
		 
	try {
		
		ps=c.prepareStatement("insert into userrole values(?,?,?,?)");
		ps.setString(1, bean.getUserName());
       ps.setString(2, bean.getPassWord());
       ps.setString(3, bean.getRoleCode());
       ps.setString(4, " ");
       ps.executeUpdate();
       
     rd=request.getRequestDispatcher("/newprofilesuccess.jsp");
		rd.forward(request, response);
	}
	catch (SQLException e) {
	
	out.println("<html><body><center><h2>This username is already taken</h2></br><a href='newprofile.jsp'><input type='submit' value='Back'></a></center></body></html>");
		e.printStackTrace();
		
	}
}
	 else
	 {
     	try {
				System.out.println(bean.getUserName());
				ps=c.prepareStatement("insert into userrole values(?,?,?,?)");
				ps.setString(1, bean.getUserName());
				 ps.setString(2, bean.getPassWord());
			        ps.setString(3, bean.getRoleCode());
			        ps.setString(4, bean.getAgent());
			        ps.executeUpdate();
			       System.out.println("added");
			        rd=request.getRequestDispatcher("/newprofilesuccess.jsp");
					rd.forward(request, response);
			} 
			catch (SQLException e) {
				out.println("<html><body><center><h2>This username is already taken</h2></br><a href='newprofile.jsp'><input type='submit' value='Back'></a></center></body></html>");
				e.printStackTrace();
				
				
			}
		}
	}
		catch (Exception e) {
			
			e.printStackTrace();
		} 
	}
	}