package com.cg.usermanagement.exception;
public class UserException extends Exception {

	private static final long serialVersionUID = 726264577455921591L;

	public UserException(String message) 
	{	
		super(message);
	}	
}