package com.cg.usermanagement.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.usermanagement.bean.AdminBean;
import com.cg.usermanagement.bean.UserBean;
import com.cg.usermanagement.connection.DBConnection;
import com.cg.usermanagement.exception.UserException;
public class UserDaoImpl implements IUserDao {
	UserBean bean = new UserBean();
	Scanner sc = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();
	public UserDaoImpl() 
	{
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	//------------------------ 1. User Management Role of Book-Store Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	CheckAdminDetails(UserBean bean2)
		 - Input Parameters	:	UserBean bean2
		 - Return Type		:	boolean
		 - Throws			:  	SQLException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	24/06/2019
		 - Description		:	Checking Admin Details
		 * @throws UserException 
		 ********************************************************************************************************/
	public boolean CheckAdminDetails(AdminBean admin) throws SQLException, UserException {
		boolean flag = false;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		preparedStatement = connection.prepareStatement(QueryMapper.LOGIN_QUERY);
		resultset = preparedStatement.executeQuery();
		while (resultset.next()) 
		{
			if (admin.getAdminEmail().equalsIgnoreCase(resultset.getString(1))
					&& admin.getAdminPassword().equals(resultset.getString(2))) {
				
				flag = true;
			}		
		}
		return flag;
	}
	/*******************************************************************************************************
	 - Function Name	:	ViewUserListing()
	 - Input Parameters	:	No Input Parameters
	 - Return Type		:	List
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Retrieving all user details
	 ********************************************************************************************************/
	public List<UserBean> ViewUserListing() throws Exception {
		List<UserBean> UserList = new ArrayList<UserBean>();
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		preparedStatement = connection.prepareStatement(QueryMapper.VIEW_DETAILS_QUERY);
		resultset = preparedStatement.executeQuery();
		while (resultset.next()) {
			UserBean bean = new UserBean();
			bean.setId(resultset.getString(2));
			bean.setMail(resultset.getString(3));
			bean.setFullName(resultset.getString(4));
			bean.setPassword(resultset.getString(5));
			UserList.add(bean);
		}
		return UserList;
	}
	/*******************************************************************************************************
	 - Function Name	:	SearchId(String id)
	 - Input Parameters	:	String id
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Searching ID 
	 ********************************************************************************************************/
	public int SearchId(String id) throws Exception {
		int response = 0;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		preparedStatement = connection.prepareStatement(QueryMapper.SEARCH_QUERY);
		preparedStatement.setString(1, id);
		resultset = preparedStatement.executeQuery();
		if (resultset.next()) {
			response = 1;
		} else {
			System.err.println("No records with given ID");	
		}
		return response;
	}	
	/*******************************************************************************************************
	 - Function Name	:	AddNewUser(UserBean bean)
	 - Input Parameters	:	UserBean bean
	 - Return Type		:	String
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Adding New User to database calls dao method  AddNewUser(UserBean bean)
	 ********************************************************************************************************/
	public String AddNewUser(UserBean bean) throws Exception {
		String i = null;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null,preparedStatement2=null;
		ResultSet resultset = null;
		int queryResult = 0;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, bean.getMail());
			preparedStatement.setString(2, bean.getFullName());
			preparedStatement.setString(3, bean.getPassword());   
			queryResult = preparedStatement.executeUpdate();
			if (queryResult == 0) {
				logger.error("Insertion failed ");
				throw new UserException("Inserting donor details failed ");
			} else {
				preparedStatement2 = connection.prepareStatement(QueryMapper.SEQ_ID_QUERY);
				logger.info("Successfully created new user");	
				resultset = preparedStatement2.executeQuery();
				while (resultset.next()) {
					i = resultset.getString(1);
				}		}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
		} finally {
			try {
				preparedStatement.close();
				preparedStatement2.close();
				connection.close();
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new UserException("Error in closing db connection");
			}	}
		return i;
	}
	/*******************************************************************************************************
	 - Function Name	:	ExistEmailOrNot(String email)
	 - Input Parameters	:	String email
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Checking e-mail already exists or not 
	 ********************************************************************************************************/
	public int ExistEmailOrNot(String email) throws SQLException, UserException {
		int result=1;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
	    try
	    {    
	    	preparedStatement = connection.prepareStatement(QueryMapper.EMAILEXISTORNOT_QUERY);
	    	resultset=preparedStatement.executeQuery();
	    	while(resultset.next())	{   		
	    		if(email.equals(resultset.getString(1)))		{      
	    			      result=0;
	    			      throw new UserException("This mail already exists");
	    				}  	}  }
	    catch(Exception e)
	    {
	    	System.err.println(e.getMessage());
	    }finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new UserException("Error in closing db connection");
			}
		}
		return result;
	}	
	/*******************************************************************************************************
	 - Function Name	:	EditUser(UserBean bean)
	 - Input Parameters	:	UserBean bean
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Updating/Editing User Details 
	 ********************************************************************************************************/
	public int EditUser(UserBean bean) throws Exception {
		int queryresult = 0,result=0;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		try {		
			 preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_QUERY);
				preparedStatement.setString(1,bean.getMail());
				preparedStatement.setString(2,bean.getFullName());
				preparedStatement.setString(3,bean.getPassword());					
				preparedStatement.setString(4, bean.getId());
				System.out.println("Do you want to update the details mentioned above Yes/No");
				String answer = sc.next();
				if (answer.equalsIgnoreCase("yes"))
				{
					queryresult = preparedStatement.executeUpdate();
					if (queryresult != 0)					
						result=1;
					 else					
						result=0;	
				} else 				
					System.exit(0);
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new UserException("Tehnical problem occured refer log");
			}
			finally {
				try {
					preparedStatement.close();
					connection.close();
				} catch (SQLException sqlException) {
					sqlException.printStackTrace();
					logger.error(sqlException.getMessage());
					throw new UserException("Error in closing db connection");
				}
			}
			return result;		
	}
	/*******************************************************************************************************
	 - Function Name	:	DeleteUser(UserBean bean)
	 - Input Parameters	:	UserBean bean
	 - Return Type		:	int
	 - Throws			:  	Exception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Deleting/Removing User Details 
	 ********************************************************************************************************/
	public int DeleteUser(UserBean bean) throws Exception {
		int queryresult = 0;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;	
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_QUERY);
			preparedStatement.setString(1, bean.getId());
			queryresult = preparedStatement.executeUpdate();
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new UserException("Tehnical problem occured refer log");
		}
		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new UserException("Error in closing db connection");
			}	}
		return queryresult;
	}}
