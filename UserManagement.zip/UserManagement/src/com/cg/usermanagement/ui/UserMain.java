package com.cg.usermanagement.ui;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.usermanagement.bean.AdminBean;
import com.cg.usermanagement.bean.UserBean;
import com.cg.usermanagement.exception.UserException;
import com.cg.usermanagement.service.UserServiceImpl;
public class UserMain {
	static Logger logger = Logger.getRootLogger();
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		AdminBean admin = new AdminBean();
		UserBean bean = new UserBean();
		UserServiceImpl service1 = new UserServiceImpl();
		boolean continuevalue = false, idflag = false, answer = false;
		int searchid = 0,result=0;
		String password1 = "";
		System.out.println("---------ADMIN PAGE----------");
		System.out.println("Enter E-mail: ");
		String mail = scanner.next();
		System.out.println("Enter Password");
		String password = scanner.next();
		admin.setAdminEmail(mail);
		admin.setAdminPassword(password);
		try {		
			answer = service1.CheckAdminDetails(admin);
			if(answer==false) {
				System.err.println("Login details are incorrect. Please enter correct details");
			}
		} catch (UserException e) {
			System.err.println(e.getMessage());
		}
		if (answer == true) {
			do {
				boolean choiceFlag = false;
				do {
					System.out
							.println("-----Under User Management-----\n 1.User Listing Page \n 2.Create New User Page\n"
									+ "3.Edit User Page\n 4.Delete User Confirmation Page");
					int choice = 0;
					boolean choice1flag = false;
					System.out.println("Enter your choice");
					try {
						choice = scanner.nextInt();
						switch (choice) {
						case 1:
							List<UserBean> UserList = new ArrayList<UserBean>();
							UserList = service1.ViewUserListing();
							if (UserList != null) {
								
								Iterator<UserBean> iterator = UserList.iterator();
								while (iterator.hasNext()) {
									System.out.println(iterator.next());
								}
							} else {
								System.out.println("No one was there in the list, yet.");
							}
							System.out.println("You want to edit/delete\n1.Edit 2.Delete ");
							do {
								int choice1 = scanner.nextInt();
								switch (choice1) {
								case 1:
									String name = "", email = "", id1 = "";
									do {
										UserServiceImpl service2 = new UserServiceImpl();
										System.out.println("Enter Id to edit the details");
										try {	
											id1 = scanner.next();
											searchid = service2.SearchId(id1);
											idflag = true;
										} catch (UserException e) {
											idflag = false;
											logger.error("exception occured", e);
											System.err.println("ERROR : " + e.getMessage());
										}
										finally {
											service2=null;
										}
									} while (searchid == 0);
									boolean emailflag1 = false;
									do {
										System.out.println("Enter E-mail");
										try {
											email = scan();
											service1.ValidateEmail(email);
											int emailexist = service1.ExistEmailOrNot(email);
											if (emailexist != 0) {
												emailflag1 = true;
												bean.setMail(email);
												break;
											}
										} catch (UserException e) {
											emailflag1 = false;
											logger.error("exception occured", e);
											System.err.println(e.getMessage());
										  }
									} while (!emailflag1);
									boolean nameflag = false;
									do {
										System.out.println("Enter Full Name");
										try {
											name = scan();
											service1.ValidateFullName(name);
											nameflag = true;
											bean.setFullName(name);
											break;
										} catch (UserException e) {
											nameflag = false;
											logger.error("exception occured", e);
											System.err.println(e.getMessage());
										}
									} while (!nameflag);
									boolean passwordflag = false;
									do {
										System.out.println("Enter Password");
										try {

											password = scan();
											service1.ValidatePassword(password);
											passwordflag = true;
											bean.setPassword(password);
											break;
										} catch (UserException e) {
											passwordflag = false;
											logger.error("exception occured", e);
											System.err.println(e.getMessage());
										}
									} while (!passwordflag);//if (searchid != 0) {
										bean.setId(id1);
										 result = service1.EditUser(bean);
										if (result != 0) {
											logger.info("Successfully updated your details");
											System.out.println(
													"Successfully Updated user details  with ID:" + bean.getId());
										} else {
											logger.error("Updation failed ");
											throw new UserException("Updating user details failed ");
										}
										choice1flag = true;
										break;	//}//choice1flag = true;
								case 2:
									do {
										UserServiceImpl service3 = new UserServiceImpl();
										System.out.println("Enter ID to delete the details");
										try {
											String idsearch = scanner.next();
											searchid = service3.SearchId(idsearch);
											if (searchid != 0) {
												bean.setId(idsearch);
												 result = service3.DeleteUser(bean);
												if (result != 0) {
													logger.info("Successfully deleted your details");
													System.out.println(
															"Successfully deleted user with ID:" + bean.getId());
												} else {
													logger.error("Deletion failed ");
												}
												idflag=true;
											}
										} catch (UserException e) {
											idflag = false;
											logger.error("exception occured", e);
											System.err.println("ERROR : " + e.getMessage());
										} finally {
											service3 = null;
										}
									} while (searchid == 0);
									choice1flag=true;
									break;
								default:
									System.out.println("Enter Correct Option");
									choice1flag = false;
									break;
								}// end of inner switch
							} while (!choice1flag);
							choiceFlag=true;
							break;
						case 2:
							boolean emailflag = false;
							do {
								do {
									System.out.println("Enter E-mail");
									try {
										String email = scan();
										service1.ValidateEmail(email);
										int emailexist = service1.ExistEmailOrNot(email);
										if (emailexist != 0) {
											emailflag = true;
											bean.setMail(email);
											break;
										}
									} catch (UserException e) {
										emailflag = false;
										logger.error("exception occured", e);
										System.err.println(e.getMessage());
									}
								} while (!emailflag);
								boolean nameflag = false;
								do {
									System.out.println("Enter Full Name");
									try {
										String name = scan();
										service1.ValidateFullName(name);
										nameflag = true;
										bean.setFullName(name);
										break;
									} catch (UserException e) {
										nameflag = false;
										logger.error("exception occured", e);
										System.err.println(e.getMessage());
									}
								} while (!nameflag);
								boolean passwordflag = false;
								do {
									System.out.println("Enter Password");
									try {
										password1 = scanner.next();
										service1.ValidatePassword(password1);
										passwordflag = true;
										bean.setPassword(password1);
										break;
									} catch (UserException e) {
										passwordflag = false;
										logger.error("exception occured", e);
										System.err.println(e.getMessage());
									}
								} while (!passwordflag);
								String id = service1.AddNewUser(bean);
								if (id == null) {
									System.out.println("E-mail already exists. Please enter another mail");
									emailflag = false;
								} else {
									logger.info("New user created successfully");
									System.out.println("New user created successfully with ID:" + id);
								}
							} while (!emailflag);
							choiceFlag = true;
							break;
						case 3:
							String name = "", email = "", id1 = "";
							do {
								UserServiceImpl service2 = new UserServiceImpl();
								System.out.println("Enter Id to edit the details");
								try {
									id1 = scanner.next();
									searchid = service2.SearchId(id1);
									idflag = true;
								} catch (UserException e) {
									idflag = false;
									logger.error("exception occured", e);
									System.err.println("ERROR : " + e.getMessage());
								}
							} while (searchid == 0);
							boolean emailflag1 = false;
							do {
								System.out.println("Enter E-mail");
								try {
									email = scan();
									service1.ValidateEmail(email);
									int emailexist = service1.ExistEmailOrNot(email);
									if (emailexist != 0) {
										emailflag1 = true;
										bean.setMail(email);
										break;
									}
								} catch (UserException e) {
									emailflag1 = false;
									logger.error("exception occured", e);
									System.err.println(e.getMessage());
								}
							} while (!emailflag1);
							boolean nameflag = false;
							do {
								System.out.println("Enter Full Name");
								try {
									name = scan();
									service1.ValidateFullName(name);
									nameflag = true;
									bean.setFullName(name);
									break;
								} catch (UserException e) {
									nameflag = false;
									logger.error("exception occured", e);
									System.err.println(e.getMessage());
								}
							} while (!nameflag);
							boolean passwordflag = false;
							do {
								System.out.println("Enter Password");
								try {
									password = scan();
									service1.ValidatePassword(password);
									passwordflag = true;
									bean.setPassword(password);
									break;
								} catch (UserException e) {
									passwordflag = false;
									logger.error("exception occured", e);
									System.err.println(e.getMessage());
								}
							} while (!passwordflag);
							if (searchid != 0) {
								bean.setId(id1);
								 result = service1.EditUser(bean);
								if (result != 0) {
									logger.info("Successfully updated your details");
									System.out.println("Successfully Updated user details  with ID:" + bean.getId());
								} else {
									logger.error("Updation failed ");
									throw new UserException("Updating user details failed ");
								}	}
							choiceFlag = true;
							break;
						case 4:
							do {
								UserServiceImpl service3 = new UserServiceImpl();
								System.out.println("Enter ID to delete the details");
								try {
									String idsearch = scanner.next();
									searchid = service3.SearchId(idsearch);
									if (searchid != 0) {
										bean.setId(idsearch);
										 result = service3.DeleteUser(bean);
										if (result != 0) {
											logger.info("Successfully deleted your details");
											System.out.println("Successfully deleted user with ID:" + bean.getId());
										} else {
											logger.error("Deletion failed ");
										}}		
								} catch (UserException e) {
									idflag = false;
									logger.error("exception occured", e);
									System.err.println("ERROR : " + e.getMessage());
								} finally {
									service3 = null;
								}
							} while (searchid == 0);
							choiceFlag = true;
							break;
						default:
							System.out.println("Please enter the digits which are ranging from 1-4:");
							break;
						}// end of switch	
					} // end of try
					catch (InputMismatchException e) {
						scanner.nextLine();
						choiceFlag = false;
						logger.error("exception occured", e);
						System.err.println("ERROR :please enter only digits");
					}} // end of while	
				while (!choiceFlag);	
				System.out.println("Do you want to continue yes/no");
				String response = scanner.next();
				if (response.equalsIgnoreCase("no")) {
					continuevalue = true; 
			} 
			}while (!continuevalue);
		}
		else {
			main(null);
		}}
	private static String scan() {
		Scanner scan = new Scanner(System.in);
		return scan.nextLine();
	}}