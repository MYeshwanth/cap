package com.cg.obs.bean;

public class PayeeBean {

	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPacc_id() {
		return pacc_id;
	}
	public void setPacc_id(String payee_id) {
		this.pacc_id = payee_id;
	}
	
	
	String nickname;
	String pacc_id;
	
}
