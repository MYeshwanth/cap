package com.cg.obs.bean;

import java.io.Serializable;
// customer details bean
public class OBSBean {

	
	public int getAcc_id() {
		return acc_id;
	}
	
	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}
	
	public String getCust_name() {
		return cust_name;
	}
	
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	
	public String getCust_email() {
		return cust_email;
	}
	
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	
	public String getCust_address() {
		return cust_address;
	}
	
	public void setCust_address(String cust_address) {
		this.cust_address = cust_address;
	}
	
	public String getPancard() {
		return pancard;
	}
	
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	
	int acc_id;
	String cust_name;
	String cust_email;
	String cust_address;
	String pancard;
	
}
