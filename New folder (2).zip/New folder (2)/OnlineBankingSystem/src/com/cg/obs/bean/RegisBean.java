package com.cg.obs.bean;

public class RegisBean {

	int acc_id;
	public int getAcc_id() {
		return acc_id;
	}
	
	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}
	
	public String getUser_id() {
		return user_id;
	}
	
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	
	public String getLogin_password() {
		return login_password;
	}
	
	public void setLogin_password(String login_password) {
		this.login_password = login_password;
	}
	
	public String getSecret() {
		return secret;
	}
	
	public void setSecret(String secret) {
		this.secret = secret;
	}
	public String getTransaction_password() {
		return transaction_password;
	}
	public void setTransaction_password(String transaction_password) {
		this.transaction_password = transaction_password;
	}
	public String getLock_status() {
		return lock_status;
	}
	public void setLock_status(String lock_status) {
		this.lock_status = lock_status;
	}
	
	
	String user_id;
	String login_password;
	String secret;
	String transaction_password;
	String lock_status;
	
}
