package com.cg.obs.bean;

public class AccountBean {

	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	public Float getAcc_bal() {
		return acc_bal;
	}
	public void setAcc_bal(Float f) {
		this.acc_bal = f;
	}
	public int getAcc_id() {
		return acc_id;
	}
	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}
	
	
	Float acc_bal;
	int acc_id;
	String acc_type;
	
	
	String cust_name;
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}


	String email;
	String pancard;

	
}
