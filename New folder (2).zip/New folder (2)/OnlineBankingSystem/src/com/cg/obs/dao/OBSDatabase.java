package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class OBSDatabase {

	 public static Connection getConnection()
			  throws Exception
			  {
				 /* Class.forName("com.mysql.jdbc.Driver");
				  Connection  conn = DriverManager.getConnection(
						  "jdbc:mysql://localhost:3306/test",
						  "root",
						  "root");*/
				
				  String driverName = "oracle.jdbc.OracleDriver";
				  Class.forName(driverName);
				  Connection con = DriverManager.getConnection(
				               "jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg633","training633");
				 
				return con;
			  }

	
}
