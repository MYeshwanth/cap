package com.cg.obs.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.obs.dao.OBSDao;
import com.cg.obs.services.OBSServices;

public class PayeeController extends HttpServlet {

	
		 
		public  void doGet(HttpServletRequest request, HttpServletResponse response) 
				   throws ServletException,IOException 
				{
					RequestDispatcher rd = null;
					int Cust_id=0;
					String title="";
					
					String payee_id=request.getParameter("pid");
					String nick_name=request.getParameter("pnickname");
					
					
					OBSServices obsservices=new OBSServices();
					
					OBSDao obsdao=new OBSDao();
					//OBSBean obsbean=new OBSBean();
					
					 int updateCount = obsservices.addpayeeobs(payee_id,nick_name);
						
						System.out.println("inserted "+updateCount+" record   Success");
						
						if (updateCount==1) {
							rd = request.getRequestDispatcher("/success.jsp");
							
						} else {
							rd = request.getRequestDispatcher("/error.jsp");
						}
						rd.forward(request, response);
					}
					
					
	
}
