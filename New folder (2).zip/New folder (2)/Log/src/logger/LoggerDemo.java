package logger;

import org.apache.log4j.Logger;

public class LoggerDemo {
public static final Logger logger=Logger.getLogger(LoggerDemo.class);
public static void main(String args[])
{
	logger.debug("this is debug");
	logger.info("this is info");
	logger.warn("\nthis is warn");
	logger.error("this is error");
	logger.fatal("this is fatal");
}
}
