package com.dao;

public interface QueryMapper 
{
	public static final String INSERT_QUERY="insert into claim values(claimnumber_seq.nextval,?,?,?,?,?,SELECT_QUERY)";
	public static final String SELECT_QUERY="SELECT POLICYNUMBER FROM POLICY";
}
