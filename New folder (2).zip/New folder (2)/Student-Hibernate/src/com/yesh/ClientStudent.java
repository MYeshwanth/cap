package com.yesh;

import org.hibernate.*;
import org.hibernate.cfg.*;
public class ClientStudent {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory  factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Student s1=new Student();
		s1.setSno(1);
		s1.setSname("yeshwanth");
		s1.setEmail("yeshwanth@gmail.com");
		s1.setMobile(99891426);
		session.save(s1);
		tx.commit();
		session.close();
	}

}
