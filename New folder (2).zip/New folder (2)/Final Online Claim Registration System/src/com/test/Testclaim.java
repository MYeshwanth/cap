package com.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.bean.Claimbean;

class Testclaim {

	@Test
	void testSetCreason() {				
		Claimbean obj=new Claimbean();
		obj.setCreason("Accident");
		assertEquals("Accident",obj.getCreason());
	}
	@Test
	void testSetAlocation() {
		Claimbean obj=new Claimbean();
		obj.setAlocation("Chennai");
		assertEquals("Chennai",obj.getAlocation());
	}
	@Test
	void testSetAcity() {
		Claimbean obj=new Claimbean();
		obj.setAcity("Sipcot");
		assertEquals("Sipcot",obj.getAcity());
	}
	@Test
	void testSetAstate() {
		Claimbean obj=new Claimbean();
		obj.setAstate("TamilNadu");
		assertEquals("TamilNadu",obj.getAstate());
	}
	@Test
	void testSetAzip() {
		Claimbean obj=new Claimbean();
		obj.setZip(12345);
		assertEquals(12345,obj.getZip());
	}
	@Test
	void testSetCtype() {
		Claimbean obj=new Claimbean();
		obj.setCtype("Mall");
		assertEquals("Mall",obj.getCtype());
	}

}