package unit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AddTest {

	@Test
	void test() {
		Myclass my=new Myclass();
		int result=my.add(100, 200);
		//fail("Not yet implemented");
				assertEquals(300,result);
	}

}
