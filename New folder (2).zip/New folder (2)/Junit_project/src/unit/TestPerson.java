package unit;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
class TestPerson {

	@Test
	public void testGetFullName()
	{
		System.out.println("from test person1");
		Person per=new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
	}
	@Test
	public void testNullsInName()
	{
		System.out.println("from test person1");
		Person per1=new Person("Robert","King");
		assertNotNull("full name null",per1.getFullName());
		assertNotNull("first name null",per1.getFirstname());//value in the object is not null
	}
    @Test
    public void testGetFirstName()
    {
    	Person p=new Person("Robert","King");
    	assertEquals(p.getFirstname(),"Robert");
    }
    @Test
    public void testGetLastName()
    {
    	Person p1=new Person("Robert","King");
    	assertEquals(p1.getLastname(),"King");
    }
}
