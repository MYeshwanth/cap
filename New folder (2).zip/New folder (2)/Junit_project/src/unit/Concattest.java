package unit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Concattest {

	@Test
	void test() {
		Myclass my1=new Myclass();
		String str=my1.concat("yeshwanth","vinay");
		assertEquals("yeshwanthvinay",str);
		
	}

}
