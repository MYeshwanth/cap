package unit;

public class Myclass {
int add(int a,int b)
{
	return a+b;
}
String concat(String s1,String s2)
{
	return s1+s2;
}
}
