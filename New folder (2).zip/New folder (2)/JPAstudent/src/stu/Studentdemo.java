package stu;
import java.io.*;

import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="students1")
public class Studentdemo implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String name;
	private String address;
	private String city;
	private float csmarks;
	private float psmarks;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public float getCsmarks() {
		return csmarks;
	}
	public void setCsmarks(float csmarks) {
		this.csmarks = csmarks;
	}
	public float getPsmarks() {
		return psmarks;
	}
	public void setPsmarks(float psmarks) {
		this.psmarks = psmarks;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
