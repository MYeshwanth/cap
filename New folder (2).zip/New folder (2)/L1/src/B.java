import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.*;
class B {
	
	
@Ignore @Test(expected=ClassCastException.class)
	
	public void testGetLastname() {
		
	}
@Ignore @Test
	
	public void GetLastname() {
		
	}
	
	
	
	
	
}

