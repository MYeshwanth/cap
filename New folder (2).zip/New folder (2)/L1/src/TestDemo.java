import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.*;
class TestDemo {

	@Ignore @Test(expected=ClassCastException.class)
	
	public void testGetLastname() {
		
	}
@Ignore @Test
	
	public void GetLastname() {
		
	}

}
