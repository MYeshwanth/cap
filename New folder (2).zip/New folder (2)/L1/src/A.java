import static java.lang.System.*;

import java.awt.List;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
public class A {
 String name;
	A(int n)
  {
	//this.n=n;
		//  name="yesh";
  }
	/*public void A(int n)
	{
		
	}
	static void print(int a,int y,String...s)
	{
		out.println(a+""+y); 
		for(int i=0;i<s.length;i++) 
			out.print(s[i]+"\t"); 
		out.println();
		} */
	public static void main(String args[]) {
	A a=new A(9);
		
	/*String str=null;
	System.out.println(str);
	int[] ae = new int[0];
    System.out.print(ae.length); */
	
    
    Set set = new TreeSet();
    set.add("3");
    set.add("1");
    set.add("2");
    
    System.out.println(set);
   
	
	
	/*
	Path javaHome = Paths.get("C:/Program Files/Java/jdk1.8.0_25");
	   System.out.println(javaHome.getNameCount());}
    
		ArrayList<Number>ai=new ArrayList<Number>();*/
		/* byte var1 = 127;
		  byte var2 = 126;
		  //byte result = var1 + var2;
*/		/*  Integer var1 = new Integer(2); 
		  Integer var2 = new Integer(2); 
		  if(var1==var2)
		  {
			  System.out.println(true);
		  }*/
	/*	ai.add("null");
		ai.add(null);
		System.out.println(ai);*/
		/*
		ai.add(new Integer(4));
		
		ai.add(new Long(4));
		
		ai.add(new Float(4));
		
		System.out.println(ai);
		
		List<Object>li=new List<Object>();*/
		
		/*Vector<String> ve=new Vector<String>();
		ve.add(new String("hello"));
		ve.add(new String("yeshwanth"));
		String st=ve.get(1+0);`
		System.out.println(st);*/
		
		String str=null;
		System.out.println(str);
		
		HashSet hs = new LinkedHashSet(); 
		hs.add("A"); 
		hs.add("A");
		hs.add("D");
		hs.add("E"); 
		hs.add(54); hs.add(34);
		System.out.println(hs);
		
	/*	Set set=new TreeSet();
		set.add("2");
		set.add("-1");
		
		set.add("48158");
		
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next()+" ");
		}*/
		/*print(1,2,"java","java 5","yeshwanth");
		out.println("Next invoke");
		print(1,2,"a","b","cfgdfg","d","e","fsdfsdvdf","ergfervg5trbv");
*/
/*	A a=new A();
	System.out.println(name);*/
	/*	String a=null;
		System.out.println(a.length());*/
		/*int a=8;*/
	/*	float d;
		System.out.println(d);*/
		
		/*try { 
			int a = args.length;
			System.out.println("a = " + a);
			int b = 42 / a;
			int c[] = { 1 }; 
			c[42] = 99;
			} 
		catch(ArrayIndexOutOfBoundsException e) 
		{
			System.out.println("Array index oob: " + e);
		} 
		catch(ArithmeticException e)
		{ 
			System.out.println("Divide by 0: " + e);
		}    
		
		catch(Exception e) 
		{ 
			System.out.println("Generic Exception: " + e);
        }
		
		
		
		System.out.println("After try/catch blocks.");
*/
		
	/*	String[] words=new String[2];
		words[0]=new String ("Haneef");
		words[1]=new String ("Yeshwanth");
		words[0]=new String ("Suresh");
		System.out.println(words.length);
		for(int i=0;i<words.length;i++)
		{
			
			System.out.println(words[i]);
		}*/
}
}
