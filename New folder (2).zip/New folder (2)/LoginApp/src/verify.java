import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class verify extends HttpServlet {

	
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps;
	String str=null;
	RequestDispatcher rd=null;
	Statement st=null;

	String uname;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession(false);
		String un=(String)session.getAttribute("name");
		String ps=(String)session.getAttribute("pass");
		
		try
		{
			 Class.forName("oracle.jdbc.OracleDriver");
			 c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg610","training610");
		ps=c.prepareStatement("select username from login where username=?");
		ps.setString(1,un);
		rs=ps.executeQuery();
		while(rs.next())
		{
			uname=rs.getString(1);
		}
	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
}
}
