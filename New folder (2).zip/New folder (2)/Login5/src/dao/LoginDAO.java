package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.nag.LoginBean;



public class LoginDAO 
{
	
	
  public static int addStudent(LoginBean bean)
  {
	  Connection con = null;
	  PreparedStatement pstmt = null;
	  try
	  {
		  
		  con=LoginDB.getConnection(); 
		  
		  String ins_str = 
			  "insert into login values(?,?)";
		  
		  pstmt = con.prepareStatement(ins_str);
		  
		  pstmt.setString(1,bean.getUsername());
		  pstmt.setString(2,bean.getPassword());
		  
		 
		  
		  
		  int updateCount = pstmt.executeUpdate();
		  
		  con.close();
		  
		  return updateCount;
		  
		  
	  }
	  catch(Exception ex)
	  {
		  System.out.println(ex.toString());
		  return 0;
	  }
	  
  }
}
  
  
