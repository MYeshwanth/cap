package services;



import com.nag.LoginBean;

import dao.LoginDAO;

//import com.ram.beans.BookBean;
//import com.ram.dao.BookDAO;

public class LoginService 
{
 public int addStudentService( String username,String password)
 {
	
	 
	 LoginDAO bookDAO = new  LoginDAO();
	 LoginBean studentBean = new LoginBean();
	 //wrap up all the four field values into bean
	 
	 
	 
	 
	 
	 studentBean.setUsername(username);
	 studentBean.setPassword(password);
	 
	 int updateResult = 0;
	 try
	 {
		 updateResult = LoginDAO.addStudent(studentBean);
		 return updateResult;
	 }
	 catch(Exception ex)
	 {
		 System.out.println(ex.toString());
		 return 0;
	 }
 }
 
}
 
 