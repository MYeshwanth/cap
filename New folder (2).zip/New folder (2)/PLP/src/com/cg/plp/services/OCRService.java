package com.cg.plp.services;

public class OCRService {

}
