package com.cg.plp.bean;

public class ClaimBean {

}
