package com.cg.plp.dao;

public class OCRDao {

}
