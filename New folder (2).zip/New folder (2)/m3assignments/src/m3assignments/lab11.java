package m3assignments;

import java.io.IOException;
import java.util.Date;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class lab11 extends GenericServlet {
	public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
	{
		Date d=new Date();
System.out.println();
	}
}